using UnityEngine;

[CreateAssetMenu(fileName = "New Item", menuName = "Inventory/Item")]
public class ItemSO : ScriptableObject
{
    [Header("Basic Info")]
    public string itemName;
    public Sprite itemIcon;
    [TextArea] public string itemDescription;

    [Header("Item Type")]
    public ItemType itemType;

    [Header("Door Unlocking")]
    public string doorIDToUnlock; // Must match DoorUnlocker.DoorID

    public bool isConsumable = true;
    // this will be used later probably ^^ for deciding if item stays after used or disappears

    public enum ItemType
    {
        None,
        DoorOpener,
        InfoItem,
        QuestItem
    }

    public virtual void UseItem()
    {
        Debug.Log($"[ItemSO] Using item: {itemName} (Type: {itemType})");

        switch (itemType)
        {
            case ItemType.DoorOpener:
                UnlockDoor();
                break;

            case ItemType.InfoItem:
                Debug.Log($"[ItemSO] Info Item Used: {itemDescription}");
                break;

            default:
                Debug.Log($"[ItemSO] {itemName} used, but it has no defined action.");
                break;
        }
    }

    private void UnlockDoor()
    {
        if (string.IsNullOrEmpty(doorIDToUnlock))
        {
            Debug.LogWarning($"[ItemSO] {itemName} tried to unlock a door, but no doorIDToUnlock was set!");
            return;
        }

        // Use the new non-obsolete method (Unity 2023+)
        DoorUnlocker[] doors = Object.FindObjectsByType<DoorUnlocker>(FindObjectsSortMode.None);
        Debug.Log($"[ItemSO] Searching for door with ID: {doorIDToUnlock} (Found {doors.Length} DoorUnlocker objects in scene)");

        foreach (DoorUnlocker door in doors)
        {
            if (door == null)
            {
                Debug.LogWarning("[ItemSO] Found a null door reference � skipping.");
                continue;
            }

            Debug.Log($"[ItemSO] Checking door: {door.name} (ID: {door.DoorID})");

            if (door.DoorID == doorIDToUnlock)
            {
                Debug.Log($"[ItemSO] Found matching door '{door.name}'. Unlocking now...");
                door.UnlockDoor();
                return;
            }
        }

        Debug.LogWarning($"[ItemSO] No door found in scene with ID: {doorIDToUnlock}");
    }
}
