using UnityEngine;

public class PersistentObject : MonoBehaviour
{
    [SerializeField] private string objectID; // Unique per collectible/destructible

    private void Start()
    {
        // Hide object if already collected or destroyed
        if (GameManager.instance == null) return;

        if (GameManager.instance.IsCollected(objectID) || GameManager.instance.IsDestroyed(objectID))
        {
            gameObject.SetActive(false);
        }
    }

    public void MarkCollected()
    {
        GameManager.instance.RegisterCollected(objectID);
        gameObject.SetActive(false);
    }

    public void MarkDestroyed()
    {
        GameManager.instance.RegisterDestroyed(objectID);
        gameObject.SetActive(false);
    }
}
