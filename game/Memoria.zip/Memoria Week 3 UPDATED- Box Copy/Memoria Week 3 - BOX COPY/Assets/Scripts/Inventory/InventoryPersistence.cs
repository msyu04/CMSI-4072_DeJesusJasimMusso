using UnityEngine;
using UnityEngine.SceneManagement;

public class InventoryPersistence : MonoBehaviour
{
    private static InventoryPersistence instance;

    [Header("Scenes where inventory is DISABLED")]
    public string[] disabledScenes;

    private void Awake()
    {
        if (instance != null)
        {
            Destroy(gameObject);
            return;
        }

        instance = this;
        DontDestroyOnLoad(gameObject);

        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        bool shouldDisable = false;

        foreach (string s in disabledScenes)
        {
            if (scene.name == s)
            {
                shouldDisable = true;
                break;
            }
        }

        gameObject.SetActive(!shouldDisable);
    }
}

//using UnityEngine;
//using UnityEngine.SceneManagement;

//public class InventoryPersistence : MonoBehaviour
//{
//    private static InventoryPersistence instance;

//    private void Awake()
//    {
//        if (instance != null)
//        {
//            Destroy(gameObject);
//            return;
//        }

//        instance = this;
//        DontDestroyOnLoad(gameObject);

//        SceneManager.sceneLoaded += OnSceneLoaded;
//    }

//    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
//    {
//        // Disable in StartMenu scene
//        if (scene.name == "MainMenu")
//        {
//            gameObject.SetActive(false);
//        }
//        else
//        {
//            gameObject.SetActive(true);
//        }
//    }
//}
