using UnityEngine;

public class Item : MonoBehaviour
{
    [SerializeField]
    private string itemName;

    [SerializeField]
    private int quantity;

    [SerializeField]
    private Sprite itemSprite;

    [TextArea]
    [SerializeField]
    private string itemDescription;

    private InventoryManager inventoryManager;



    void Start()
    {
        inventoryManager = GameObject.Find("InventoryCanvas").GetComponent<InventoryManager>();
    }

    //private void OnTriggerEnter2D(Collider2D collision)
    //{
    //    if (collision.gameObject.CompareTag("Player"))
    //    {
    //        int leftOverItems = inventoryManager.AddItem(itemName, quantity, itemSprite, itemDescription);
    //        if (leftOverItems <= 0)
    //        {
    //            Destroy(gameObject);
    //        }
    //        else
    //        {
    //            quantity = leftOverItems;
    //        }

    //        // Tell GameManager it's collected
    //        GetComponent<PersistentObject>()?.MarkCollected();

    //        Destroy(gameObject);
    //    }
    //}

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            int leftOverItems = inventoryManager.AddItem(itemName, quantity, itemSprite, itemDescription);

            if (leftOverItems > 0)
            {
                quantity = leftOverItems;
                return; // don�t destroy yet
            }

            // mark collected (only if fully picked up)
            GetComponent<PersistentObject>()?.MarkCollected();

            Destroy(gameObject);
        }
    }
}
