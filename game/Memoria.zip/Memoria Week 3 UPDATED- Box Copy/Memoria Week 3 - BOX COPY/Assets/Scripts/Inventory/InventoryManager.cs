using UnityEngine;
using UnityEngine.SceneManagement;

public class InventoryManager : MonoBehaviour
{
    public static InventoryManager instance; //singleton instance

    public GameObject InventoryMenu;
    private bool menuActive;
    public ItemSlot[] itemSlot; // an array

    public ItemSO[] itemSOs;

    public ItemSlot selectedSlot; // track which slot is selected

    public GameObject inventoryButton;


    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject); // Optional: keeps it across scenes
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void OnEnable()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
    }

    void OnDisable()
    {
        SceneManager.sceneLoaded -= OnSceneLoaded;
    }

    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        // Make sure inventory menu starts closed in every scene (except main menu)
        if (scene.name != "MainMenu")
        {
            InventoryMenu.SetActive(false);
            menuActive = false;
        }

        // Re-establish slot selection state
        DeselectAllSlots();

        // Reconnect button listener if necessary
        // (Only if your button is NOT inside this object)
    }


    void Start()
    {
        InventoryMenu.SetActive(false);
        DeselectAllSlots();
    }

    public void ToggleInventory()
    {
        menuActive = !menuActive;
        InventoryMenu.SetActive(menuActive);
    }

    public void ForceCloseInventory()
    {
        menuActive = false;
        InventoryMenu.SetActive(false);
    }

    // used when we click item in item slot // itll be a button under item description later
    public void UseItem(string itemName)
    {
        for (int i = 0; i < itemSOs.Length; i++)
        {
            if (itemSOs[i].itemName == itemName)
            {
                itemSOs[i].UseItem();
            }
        }
    }

    public void UseSelectedItem()
    {
        ItemSlot selectedSlot = GetSelectedSlot();

        if (selectedSlot == null)
        {
            Debug.Log("No item selected!");
            return;
        }

        Debug.Log("Button clicked: using " + selectedSlot.itemName);

        //if (selectedSlot.itemName.Equals("Diamond Key", System.StringComparison.OrdinalIgnoreCase))
        if (selectedSlot.itemName.Equals("Key of Love", System.StringComparison.OrdinalIgnoreCase))
        {
            DoorTrigger doorTrigger = Object.FindFirstObjectByType<DoorTrigger>();

            if (doorTrigger != null)
            {
                bool canUse = doorTrigger.CanUseDoor();
                Debug.Log($"Checking if door can be used: {canUse}");

                if (canUse)
                {
                    doorTrigger.OpenDoor();
                    Debug.Log(" Diamond key used on door!");
                }
                else
                {
                    Debug.Log("Player is not near the door!");
                }
            }
            else
            {
                Debug.LogWarning("No DoorTrigger found in the scene!");
            }
        }

        if (selectedSlot.itemName.Equals("Flute", System.StringComparison.OrdinalIgnoreCase))
        {
            DoorTrigger doorTrigger = Object.FindFirstObjectByType<DoorTrigger>();

            if (doorTrigger != null)
            {
                bool canUse = doorTrigger.CanUseDoor();
                Debug.Log($"Checking if door can be used: {canUse}");

                if (canUse)
                {
                    doorTrigger.OpenDoor();
                    Debug.Log(" Flute used on snorlax!");
                }
                else
                {
                    Debug.Log("Player is not near the door!");
                }
            }
            else
            {
                Debug.LogWarning("No DoorTrigger found in the scene!");
            }
        }

    }





    public int AddItem(string itemName, int quantity, Sprite itemSprite, string itemDescription)
    {
        Debug.Log("itemName = " + itemName + "quantity = " + quantity + "itemSprite = " + itemSprite);
        for (int i = 0; i < itemSlot.Length; i++)
        {
            if(itemSlot[i].isFull == false && itemSlot[i].itemName == itemName)
            {
                int leftOverItems = itemSlot[i].AddItem(itemName, quantity, itemSprite, itemDescription);
                // AUTO SELECT THIS SLOT
                SelectSlot(itemSlot[i]);
                if (leftOverItems > 0)
                {
                    return AddItem(itemName, leftOverItems, itemSprite, itemDescription);
                }
                return 0;
            }
        }

        // if no existing stack found, find an empty slot
        for (int i = 0; i < itemSlot.Length; i++)
        {
            if (string.IsNullOrEmpty(itemSlot[i].itemName))
            {
                int leftOverItems = itemSlot[i].AddItem(itemName, quantity, itemSprite, itemDescription);
                // AUTO SELECT THIS SLOT
                SelectSlot(itemSlot[i]);
                if (leftOverItems > 0)
                    return AddItem(itemName, leftOverItems, itemSprite, itemDescription);

                return 0;
            }
        }

        // if no slot available, return remaining quantity (inventory full)
        Debug.Log("Inventory is full! Could not add " + itemName);
        return quantity;
    }

    public void DeselectAllSlots()
    {
        for (int i = 0; i <itemSlot.Length; i++)
        {
            itemSlot[i].selectedShader.SetActive(false);
            itemSlot[i].thisItemSelected = false;
        }
    }

    public void SetSelectedSlot(ItemSlot slot)
    {
        selectedSlot = slot;
    }

    public ItemSlot GetSelectedSlot()
    {
        return selectedSlot;
    }

    public string GetSelectedItemName()
    {
        if (selectedSlot != null && !string.IsNullOrEmpty(selectedSlot.itemName))
            return selectedSlot.itemName;
        return null;
    }

    public void SelectSlot(ItemSlot slot)
    {
        DeselectAllSlots();

        slot.selectedShader.SetActive(true);
        slot.thisItemSelected = true;

        selectedSlot = slot;

        // Update description UI
        slot.ItemDescriptionNameText.text = slot.itemName;
        slot.ItemDescriptionText.text = slot.itemDescription;
        slot.itemDescriptionImage.sprite = slot.itemSprite;
    }

}
