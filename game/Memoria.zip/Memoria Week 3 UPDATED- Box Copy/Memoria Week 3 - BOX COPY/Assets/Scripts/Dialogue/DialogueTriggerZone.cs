using UnityEngine;
using System.Collections;

public class DialogueTriggerZone : MonoBehaviour
{
    public SimpleDialogue dialogueManager;

    [Header("Dialogue Data")]
    public string[] speakers;
    [TextArea(2, 5)]
    public string[] lines;
    public Sprite[] portraits;

    bool triggered = false;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (triggered) return;

        if (other.CompareTag("Player"))
        {
            triggered = true;
            StartCoroutine(StartDialogueSequence(other));
        }
    }

    IEnumerator StartDialogueSequence(Collider2D player)
    {
        Rigidbody2D rb = player.GetComponent<Rigidbody2D>();
        Animator anim = player.GetComponent<Animator>();
        PlayerMovement pm = player.GetComponent<PlayerMovement>();

        // WAIT UNTIL PLAYER IS GROUNDED
        while (rb != null && Mathf.Abs(rb.linearVelocity.y) > 0.05f)
        {
            yield return null;
        }

        // STOP MOVEMENT
        if (rb != null)
            rb.linearVelocity = Vector2.zero;

        // FORCE IDLE ANIMATION
        if (anim != null)
        {
            anim.SetFloat("MoveSpeed", 0);
            anim.SetBool("isRunning", false);
            anim.SetBool("isJumping", false);
        }

        // DISABLE PLAYER CONTROL
        if (pm != null)
            pm.enabled = false;

        yield return new WaitForSeconds(0.1f);

        // START DIALOGUE
        dialogueManager.StartDialogue(speakers, lines, portraits);

        // WAIT UNTIL DIALOGUE ENDS
        while (dialogueManager.IsTalking())
            yield return null;

        // RE-ENABLE PLAYER
        if (pm != null)
            pm.enabled = true;

        Destroy(gameObject);
    }
}


//old

//using UnityEngine;
//using System.Collections;

//public class DialogueTriggerZone : MonoBehaviour
//{
//    public SimpleDialogue dialogueManager;

//    [TextArea(2, 5)]
//    public string[] lines;

//    bool triggered = false;

//    private void OnTriggerEnter2D(Collider2D other)
//    {
//        if (triggered) return;

//        if (other.CompareTag("Player"))
//        {
//            triggered = true;
//            StartCoroutine(StartDialogueWhenGrounded(other));
//        }
//    }

//    IEnumerator StartDialogueWhenGrounded(Collider2D player)
//    {
//        Rigidbody2D rb = player.GetComponent<Rigidbody2D>();

//        // Wait until player lands
//        while (rb != null && Mathf.Abs(rb.linearVelocity.y) > .05f)
//        {
//            yield return null;
//        }

//        // stop movement
//        if (rb != null)
//            rb.linearVelocity = Vector2.zero;

//        // force idle animation
//        Animator anim = player.GetComponent<Animator>();

//        if (anim != null)
//        {
//            anim.SetFloat("MoveSpeed", 0);
//            anim.SetBool("isRunning", false);
//            anim.SetBool("isJumping", false);
//        }

//        // disable controls
//        PlayerMovement pm =
//            player.GetComponent<PlayerMovement>();

//        if (pm != null)
//            pm.enabled = false;

//        // start dialogue
//        dialogueManager.StartDialogue(lines);

//        Destroy(gameObject);
//    }
//}
