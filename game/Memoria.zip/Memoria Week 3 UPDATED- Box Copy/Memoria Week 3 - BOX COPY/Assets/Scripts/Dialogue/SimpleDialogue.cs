using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;

public class SimpleDialogue : MonoBehaviour
{
    [Header("UI")]
    public GameObject dialogueCanvas;
    public TMP_Text speakerText;
    public TMP_Text dialogueText;
    public Image portraitImage;

    [Header("Typing")]
    public float typeSpeed = 0.03f;

    private string[] speakers;
    private string[] lines;
    private Sprite[] portraits;

    private int step = 0;
    private bool isTyping = false;
    private bool isTalking = false;

    private Coroutine typingCoroutine;

    //[Header("Inventory")]
    //public GameObject inventoryUI;
    //public GameObject inventoryButton;
    InventoryManager inventoryManager;




    void Start()
    {
        inventoryManager = FindFirstObjectByType<InventoryManager>();
    }


    // START DIALOGUE
    public void StartDialogue(string[] newSpeakers, string[] newLines, Sprite[] newPortraits)
    {
        speakers = newSpeakers;
        lines = newLines;
        portraits = newPortraits;

        step = 0;
        isTalking = true;

        dialogueCanvas.SetActive(true);

        // LOCK INVENTORY
        //if (inventoryUI != null)
        //    inventoryUI.SetActive(false);

        //if (inventoryButton != null)
        //    inventoryButton.SetActive(false);
        if (inventoryManager != null)
        {
            // FORCE CLOSE INVENTORY IF OPEN
            //inventoryManager.InventoryMenu.SetActive(false);

            // also reset toggle state so it doesn't think it's still open
            inventoryManager.ForceCloseInventory();

            // Hide the inventory button ONLY
            inventoryManager.inventoryButton.SetActive(false);
        }


        ShowLine();
    }


    void Update()
    {
        if (!isTalking) return;

        if (Input.GetMouseButtonDown(0))
        {
            if (isTyping)
            {
                FinishTyping();
            }
            else
            {
                NextLine();
            }
        }
    }

    void ShowLine()
    {
        speakerText.text = speakers[step];
        portraitImage.sprite = portraits[step];

        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        typingCoroutine = StartCoroutine(TypeLine(lines[step]));
    }

    IEnumerator TypeLine(string line)
    {
        isTyping = true;
        dialogueText.text = "";

        foreach (char c in line)
        {
            dialogueText.text += c;
            yield return new WaitForSeconds(typeSpeed);
        }

        isTyping = false;
    }

    void FinishTyping()
    {
        if (typingCoroutine != null)
            StopCoroutine(typingCoroutine);

        dialogueText.text = lines[step];
        isTyping = false;
    }

    void NextLine()
    {
        step++;

        if (step >= lines.Length)
        {
            EndDialogue();
            return;
        }

        ShowLine();
    }

    void EndDialogue()
    {
        dialogueCanvas.SetActive(false);
        isTalking = false;

        if (inventoryManager != null)
        {
            inventoryManager.inventoryButton.SetActive(true);
        }
    }

    public bool IsTalking()
    {
        return isTalking;
    }
}
