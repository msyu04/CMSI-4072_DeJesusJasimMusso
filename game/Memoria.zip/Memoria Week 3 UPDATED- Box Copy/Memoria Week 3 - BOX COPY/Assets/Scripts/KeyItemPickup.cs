using UnityEngine;

public class KeyItemPickup : MonoBehaviour
{
    public GameObject barrierToRemove;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            // remove invisible barrier
            barrierToRemove.SetActive(false);

            // remove item from scene
            gameObject.SetActive(false);
        }
    }
}