using UnityEngine;

public class RockSpawner : MonoBehaviour
{
    public GameObject rockPrefab;
    public float spawnRate = 2f;

    public float spawnWidth = 6f;

    void Start()
    {
        InvokeRepeating(
            nameof(SpawnRock),
            1f,
            spawnRate
        );
    }

    void SpawnRock()
    {
        Vector3 spawnPos = transform.position +
           new Vector3(
             Random.Range(-spawnWidth, spawnWidth),
             0,
             0
           );

        Instantiate(
            rockPrefab,
            spawnPos,
            Quaternion.identity
        );
    }

    void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.red;

        Gizmos.DrawWireCube(
            transform.position,
            new Vector3(
                spawnWidth * 2,
                1f,
                1f
            )
        );
    }
}