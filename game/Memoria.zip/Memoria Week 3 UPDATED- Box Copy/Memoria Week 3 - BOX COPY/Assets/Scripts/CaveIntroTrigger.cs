using UnityEngine;

public class CaveIntroTrigger : MonoBehaviour
{
    public SimpleDialogue dialogueManager;
    public PersistentObject persistentObject;

    [TextArea(2, 5)]
    public string[] lines;

    private bool triggered = false;

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Cave trigger hit by: " + other.name);

        if (triggered) return;

        if (other.CompareTag("Player"))
        {
            triggered = true;

            //dialogueManager.StartDialogue(lines, gameObject, persistentObject);
            //TESTING
            //
            //
            //
            //
            //
            //
            //
            //
            //dialogueManager.StartDialogue(lines);
        }
    }
}