using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ShadowWalkToWater : MonoBehaviour
{
    [Header("Movement")]
    public float moveDistance = 2f;
    public float moveSpeed = 2f;

    [Header("Dialogue")]
    public SimpleDialogue dialogueManager;

    [TextArea(2, 5)]
    public string[] speakers;

    [TextArea(2, 8)]
    public string[] lines;

    public Sprite[] portraits;

    [Header("Scene Transition")]
    public string nextSceneName;
    public float delayAfterDialogue = 1.5f;

    Animator anim;
    Vector3 targetPos;

    void Start()
    {
        anim = GetComponent<Animator>();
        targetPos = transform.position + Vector3.right * moveDistance;

        StartCoroutine(SceneSequence());
    }

    IEnumerator SceneSequence()
    {
        // walk to lake edge
        while (Vector3.Distance(transform.position, targetPos) > .05f)
        {
            transform.position = Vector3.MoveTowards(
                transform.position,
                targetPos,
                moveSpeed * Time.deltaTime
            );

            yield return null;
        }

        // small pause
        yield return new WaitForSeconds(1f);

        // START FULL DIALOGUE (NEW SYSTEM)
        dialogueManager.StartDialogue(speakers, lines, portraits);

        // wait until dialogue finishes
        while (dialogueManager.IsTalking())
        {
            yield return null;
        }

        yield return new WaitForSeconds(delayAfterDialogue);

        // load next scene
        SceneManager.LoadScene(nextSceneName);
    }
}