using UnityEngine;

public class DestroyTargetOnTouch : MonoBehaviour
{
    public GameObject objectToRemove;

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            Destroy(objectToRemove);
        }
    }
}