using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public static GameManager instance; // singleton instance
    // dictionary for items in inventory
    private Dictionary<string,int> collectedItems = new Dictionary<string, int>();

    // Keep track of what items/objects are gone in every scene
    public HashSet<string> collectedGameObjects = new HashSet<string>();
    public HashSet<string> destroyedObjects = new HashSet<string>();

    private string nextSpawnPoint;
    // for scene transition

    void Awake()
    {
        if (instance == null)
        {
            instance = this;
            DontDestroyOnLoad(gameObject);
            Debug.Log("GameManager initialized");
        }
        else
        {
            Debug.LogError("Multiple GameManager instances found! Destroying this one.");
            Destroy(gameObject);
        }
    }


    /// <summary>
    /// for spawn points and scene transitions
    /// </summary>
    public void SetSpawnPoint(string spawnPoint)
    {
        nextSpawnPoint = spawnPoint;
    }

    public string GetSpawnPoint()
    {
        return nextSpawnPoint;
    }

    ////


    /// <summary>
    /// this is the methods used to track what game objects were collected so that when the scene loads, they won't spawn
    /// </summary>
    /// <param name="id"></param>
    public void RegisterCollected(string id)
    {
        collectedGameObjects.Add(id);
    }

    public void RegisterDestroyed(string id)
    {
        destroyedObjects.Add(id);
    }

    public bool IsCollected(string id)
    {
        return collectedGameObjects.Contains(id);
    }

    public bool IsDestroyed(string id)
    {
        return destroyedObjects.Contains(id);
    }

    /// <summary>
    /// ////////
    /// </summary>

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.I))
        {
            DebugCollectedItems();
        }
    }

    public void DebugCollectedItems()
    {
        Debug.Log("=== GameManager Items ===");
        foreach (var item in collectedItems)
        {
            Debug.Log($"Item: {item.Key}, Quantity: {item.Value}");
        }
    }


    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

}
