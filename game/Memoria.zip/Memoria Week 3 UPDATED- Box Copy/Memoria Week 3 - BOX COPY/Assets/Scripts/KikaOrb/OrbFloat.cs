using UnityEngine;

public class OrbFloat : MonoBehaviour
{
    public float floatHeight = 0.25f;
    public float floatSpeed = 2f;

    public float swayAmount = 0.08f;
    public float swaySpeed = 1.5f;

    Vector3 startPos;

    void Start()
    {
        startPos = transform.position;
    }

    void Update()
    {
        float y =
            Mathf.Sin(Time.time * floatSpeed)
            * floatHeight;

        float x =
            Mathf.Cos(Time.time * swaySpeed)
            * swayAmount;

        transform.position =
            startPos +
            new Vector3(x, y, 0);
    }
}