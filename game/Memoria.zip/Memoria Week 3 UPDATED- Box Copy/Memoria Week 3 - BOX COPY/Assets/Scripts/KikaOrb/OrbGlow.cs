using UnityEngine;

public class OrbGlow : MonoBehaviour
{
    SpriteRenderer sr;

    public float pulseSpeed = 2f;
    public float minAlpha = .5f;
    public float maxAlpha = 1f;

    void Start()
    {
        sr = GetComponent<SpriteRenderer>();
    }

    void Update()
    {
        Color c = sr.color;

        c.a =
        Mathf.Lerp(
            minAlpha,
            maxAlpha,
            (Mathf.Sin(Time.time * pulseSpeed) + 1) / 2
        );

        sr.color = c;
    }
}