using UnityEngine;

public class DoorUnlocker : MonoBehaviour
{
    [SerializeField] private string doorID;
    [SerializeField] private float unlockRange = 3f; // distance player must be within

    public string DoorID => doorID;

    public void UnlockDoor()
    {
        GameObject player = GameObject.FindGameObjectWithTag("Player");
        if (player == null)
        {
            Debug.LogWarning("No player found in scene!");
            return;
        }

        float distance = Vector2.Distance(player.transform.position, transform.position);
        if (distance <= unlockRange)
        {
            Debug.Log($"Door '{doorID}' unlocked! Player was {distance:F1} units away.");

            // Try to mark parent as destroyed for persistence
            PersistentObject persistent = transform.parent?.GetComponent<PersistentObject>();
            if (persistent != null)
            {
                persistent.MarkDestroyed();
            }
            else
            {
                gameObject.SetActive(false); // fallback
            }
        }

        else
        {
            Debug.Log($"Player too far to unlock '{doorID}' (distance = {distance:F1}).");
        }
    }
}
