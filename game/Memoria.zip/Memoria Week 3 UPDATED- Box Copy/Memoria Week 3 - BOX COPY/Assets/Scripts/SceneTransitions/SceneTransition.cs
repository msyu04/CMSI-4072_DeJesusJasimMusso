using UnityEngine;
using UnityEngine.SceneManagement;

public class SceneTransition : MonoBehaviour
{
    [SerializeField] private string sceneToLoad;  // e.g., "Scene2"
    [SerializeField] private string targetSpawnPoint; // e.g., "Entrance_From_Scene1"

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log($"[{name}] was triggered by {other.name}");

        if (other.CompareTag("Player"))
        {
            Debug.Log($"[{name}] is transitioning to {sceneToLoad} (spawn point: {targetSpawnPoint})");
            //GameManager.instance.SetSpawnPoint(targetSpawnPoint);
            if (GameManager.instance == null)
            {
                Debug.LogWarning("GameManager missing � creating one.");

                GameObject gm = new GameObject("GameManager");
                gm.AddComponent<GameManager>();
            }

            GameManager.instance.SetSpawnPoint(targetSpawnPoint);
            SceneManager.LoadScene(sceneToLoad);
        }
    }

}
