using UnityEngine;

public class FallingRock : MonoBehaviour
{
    public float fallSpeed = 3f;

    Transform respawnPoint;
    Rigidbody2D rb;

    void Start()
    {
        respawnPoint = GameObject.FindGameObjectWithTag("Respawn").transform;
        rb = GetComponent<Rigidbody2D>();

        rb.gravityScale = 0f; // IMPORTANT: disables acceleration
        rb.linearVelocity = Vector2.down * fallSpeed; // constant speed
    }

    void Update()
    {
        transform.Translate(Vector2.down * fallSpeed * Time.deltaTime);

        if (transform.position.y < -20f)
            Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            other.transform.position = respawnPoint.position;
            Destroy(gameObject);
        }
    }
}