using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class ViewToCredits : MonoBehaviour
{
    public float holdTime = 10f;
    public string creditsSceneName;

    public ScreenFader fader;

    void Start()
    {
        StartCoroutine(Sequence());
    }

    IEnumerator Sequence()
    {
        // fade IN (reveal view)
        yield return fader.FadeIn();

        // let player absorb the view
        yield return new WaitForSeconds(holdTime);

        // fade OUT again
        yield return fader.FadeOut();

        // go to credits
        SceneManager.LoadScene(creditsSceneName);
    }
}