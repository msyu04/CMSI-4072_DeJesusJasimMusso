using UnityEngine;

public class BackgroundController : MonoBehaviour
{
    public GameObject cam;
    public float parallaxEffect;
    private float startPosX;
    private float startPosY;
    
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        startPosX = transform.position.x;
        startPosY = transform.position.y;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        float distanceX = cam.transform.position.x * parallaxEffect;
        float distanceY = cam.transform.position.y * parallaxEffect / 4;
        transform.position = new Vector3(distanceX + startPosX, distanceY + startPosY, transform.position.z);
    }
}
