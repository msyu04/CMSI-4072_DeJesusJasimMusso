using UnityEngine;

public class FallingRock3 : MonoBehaviour
{
    public float fallSpeed = 6f;

    Transform respawnPoint;

    void Start()
    {
        respawnPoint =
            GameObject.FindGameObjectWithTag("Respawn3").transform;
    }

    void Update()
    {
        transform.Translate(Vector2.down * fallSpeed * Time.deltaTime);

        if (transform.position.y < -10f)
            Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            other.transform.position =
                respawnPoint.position;

            Destroy(gameObject);
        }
    }
}