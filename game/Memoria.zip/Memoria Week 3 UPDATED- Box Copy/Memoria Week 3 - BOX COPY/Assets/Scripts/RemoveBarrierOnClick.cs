using UnityEngine;

public class RemoveBarrierOnClick : MonoBehaviour
{
    public GameObject barrier;

    void OnMouseDown()
    {
        if (barrier != null)
        {
            barrier.SetActive(false);
        }
    }
}