using UnityEngine;

public class PlayerSpawnPoint : MonoBehaviour
{
    [SerializeField] private string spawnID;

    void Awake()
    {
        if (GameManager.instance == null) return;

        string targetID = GameManager.instance.GetSpawnPoint();
        if (targetID == spawnID)
        {
            // Find the player and move them here
            GameObject player = GameObject.FindGameObjectWithTag("Player");
            if (player != null)
            {
                player.transform.position = transform.position;
                Debug.Log($"Player spawned at {spawnID}");
            }
        }
    }
}
