

using UnityEngine;

public class CameraFollowPlayer : MonoBehaviour
{
    public Transform player;
    public Vector3 startPos;
    public float minX, maxX, minY, maxY;
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {

    }

    void Update()
    {
        Vector3 playerLoc = player.position;

        float x = Mathf.Clamp(playerLoc.x, minX, maxX);
        float y = Mathf.Clamp(playerLoc.y, minY, maxY);

        transform.position = new Vector3(x, y, -10f);
    }
}
