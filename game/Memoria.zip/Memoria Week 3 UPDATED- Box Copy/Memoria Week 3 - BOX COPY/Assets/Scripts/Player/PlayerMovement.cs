using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private Transform groundCheck; // Empty object at player feet
    [SerializeField] private float groundCheckRadius = 0.2f;
    [SerializeField] private LayerMask groundLayer;

    private bool isGrounded;

    float horizontalInput;
    float walkSpeed = 3f; // new
    float runSpeed = 5f; // new
    float currentSpeed; // new
    bool isRunning = false; // toggle flag
    bool isFacingRight = false;
    float jumpPower = 10f;
    //bool isJumping = false;

    Rigidbody2D rb;
    Animator animator;

    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        currentSpeed = walkSpeed; // default = walk
    }

    // Update is called once per frame
    void Update()
    {
        // Ground check each frame
        isGrounded = Physics2D.OverlapCircle(groundCheck.position, groundCheckRadius, groundLayer);

        horizontalInput = Input.GetAxis("Horizontal");

        if (Input.GetKeyDown(KeyCode.LeftShift) || Input.GetKeyDown(KeyCode.RightShift))
        {
            isRunning = !isRunning; // flip state
        }

        // Apply correct speed based on toggle
        currentSpeed = isRunning ? runSpeed : walkSpeed;

        flipSprite();

        if(Input.GetButtonDown("Jump") && isGrounded)
        {
            rb.linearVelocity = new Vector2(rb.linearVelocity.x, jumpPower);
        }

        // Animator updates
        //animator.SetFloat("Speed", Mathf.Abs(horizontalInput));
        float normalizedSpeed = Mathf.Abs(horizontalInput) * (isRunning ? 2f : 1f);//
        animator.SetFloat("MoveSpeed", normalizedSpeed);//
        animator.SetBool("isRunning", isRunning);
        animator.SetBool("isJumping", !isGrounded); // inverse of grounded

        // Update animator
        //animator.SetFloat("Speed", Mathf.Abs(rb.linearVelocity.x));
        //animator.SetBool("isRunning", isRunning);
        //float animSpeed = 0f;

        //if (Mathf.Abs(horizontalInput) > 0.01f)
        //{
        //    animSpeed = isRunning ? 2f : 1f; // run vs walk
        //}
        //else
        //{
        //    animSpeed = 0f; //idle
        //}

        //animator.SetFloat("Speed", animSpeed);
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = new Vector2(horizontalInput * currentSpeed, rb.linearVelocity.y);
    }

    void flipSprite()
    {
        if(isFacingRight && horizontalInput < 0f || !isFacingRight && horizontalInput > 0f)
        {
            isFacingRight = !isFacingRight;
            Vector3 ls = transform.localScale;
            ls.x *= -1f;
            transform.localScale = ls;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        //isJumping = false;
    }

    private void OnDrawGizmosSelected()
    {
        if (groundCheck != null)
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(groundCheck.position, groundCheckRadius);
        }
    }
}
