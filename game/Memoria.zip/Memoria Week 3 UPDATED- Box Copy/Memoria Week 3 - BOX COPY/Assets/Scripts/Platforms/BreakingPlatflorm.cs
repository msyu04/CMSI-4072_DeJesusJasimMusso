using UnityEngine;

public class BreakawayPlatform : MonoBehaviour
{
    public float breakDelay = 0.7f;

    Rigidbody2D rb;
    bool triggered = false;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();

        rb.bodyType = RigidbodyType2D.Kinematic;
    }

    void OnCollisionEnter2D(Collision2D collision)
    {
        if (triggered) return;

        if (collision.gameObject.CompareTag("Player"))
        {
            triggered = true;
            Invoke(
                nameof(BreakPlatform),
                breakDelay
            );
        }
    }

    void BreakPlatform()
    {
        rb.bodyType = RigidbodyType2D.Dynamic;
    }
}