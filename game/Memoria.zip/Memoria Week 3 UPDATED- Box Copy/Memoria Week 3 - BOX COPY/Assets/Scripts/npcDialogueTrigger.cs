using UnityEngine;

public class NPCDialogue : MonoBehaviour
{
    public SimpleDialogue dialogueManager;
    public PersistentObject persistentObject;
    //new
    public GameObject barrier;

    [TextArea(2, 5)]
    public string[] lines;

    private bool hasInteracted = false;

    void OnMouseDown()
    {
        if (hasInteracted) return;

        hasInteracted = true;

        //dialogueManager.StartDialogue(lines, gameObject, persistentObject);
        //TESTING
        //
        //
        //
        //
        //
        //
        //
        //
        //dialogueManager.StartDialogue(lines);
        //new
        if (barrier != null)
        {
            barrier.SetActive(false);
        }
    }
}


//using UnityEngine;

//public class NPCDialogueTrigger : MonoBehaviour
//{
//    public SimpleDialogue dialogueManager;

//    [TextArea]
//    public string[] dialogueLines;

//    private bool hasTalked = false;

//    void OnMouseDown()
//    {
//        if (!hasTalked && !dialogueManager.IsTalking())
//        {
//            dialogueManager.StartDialogue(dialogueLines);
//            hasTalked = true;
//        }
//    }
//}