using UnityEngine;

public class FallingRock2 : MonoBehaviour
{
    public float fallSpeed = 4f;

    Transform respawnPoint;

    void Start()
    {
        respawnPoint =
            GameObject.FindGameObjectWithTag("Respawn2").transform;
    }

    void Update()
    {
        transform.Translate(Vector2.down * fallSpeed * Time.deltaTime);

        if (transform.position.y < -20f)
            Destroy(gameObject);
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            other.transform.position =
                respawnPoint.position;

            Destroy(gameObject);
        }
    }
}