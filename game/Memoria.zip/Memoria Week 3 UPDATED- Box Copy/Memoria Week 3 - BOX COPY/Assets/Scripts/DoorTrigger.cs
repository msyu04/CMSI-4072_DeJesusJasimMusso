using UnityEngine;

public class DoorTrigger : MonoBehaviour
{
    private bool playerInRange = false;

    void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("Something entered the door trigger: " + other.name);

        if (other.CompareTag("Player"))
        {
            playerInRange = true;
            Debug.Log(" Player entered door area");
        }
    }

    void OnTriggerExit2D(Collider2D other)
    {
        if (other.CompareTag("Player"))
        {
            playerInRange = false;
            Debug.Log(" Player left door area");
        }
    }

    public bool CanUseDoor()
    {
        Debug.Log("Checking if door can be used: " + playerInRange);
        return playerInRange;
    }

    public void OpenDoor()
    {
        Debug.Log("Door opened and destroyed");

        // Mark the parent door as destroyed for persistence
        PersistentObject persistent = transform.parent?.GetComponent<PersistentObject>();
        if (persistent != null)
        {
            persistent.MarkDestroyed();  // This will also hide the door
        }
        else
        {
            GetComponent<PersistentObject>()?.MarkDestroyed();
        }
    }



}
