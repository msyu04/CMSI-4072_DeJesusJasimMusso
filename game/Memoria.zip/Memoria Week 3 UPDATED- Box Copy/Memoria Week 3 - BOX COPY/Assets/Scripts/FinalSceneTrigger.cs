using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class FinalSceneTrigger : MonoBehaviour
{
    public Transform playerTargetPos; // where player should stand
    public SimpleDialogue dialogueManager;

    [TextArea(2, 5)]
    public string[] speakers;

    [TextArea(2, 8)]
    public string[] lines;

    public Sprite[] portraits;

    public ScreenFader fader;

    bool triggered = false;

    //public Transform standPoint; // position next to shadow

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (triggered) return;

        if (other.CompareTag("Player"))
        {
            triggered = true;

            StartCoroutine(FinalSequence(other.gameObject));
        }
    }

    IEnumerator FinalSequence(GameObject player)
    {
        Rigidbody2D rb = player.GetComponent<Rigidbody2D>();
        Animator anim = player.GetComponent<Animator>();
        PlayerMovement pm = player.GetComponent<PlayerMovement>();

        // WAIT UNTIL PLAYER IS GROUNDED
        while (rb != null && Mathf.Abs(rb.linearVelocity.y) > 0.05f)
        {
            yield return null;
        }

        // STOP MOVEMENT
        if (rb != null)
            rb.linearVelocity = Vector2.zero;

        // FORCE IDLE ANIMATION
        if (anim != null)
        {
            anim.SetFloat("MoveSpeed", 0);
            anim.SetBool("isRunning", false);
            anim.SetBool("isJumping", false);
        }

        // DISABLE PLAYER CONTROL
        if (pm != null)
            pm.enabled = false;

        yield return new WaitForSeconds(0.1f);

        // start dialogue
        dialogueManager.StartDialogue(speakers, lines, portraits);

        // wait until dialogue ends
        while (dialogueManager.IsTalking())
        {
            yield return null;
        }

        // short pause
        yield return new WaitForSeconds(1f);

        // fade to black
        yield return fader.FadeOut();

        // LOAD NEXT SCENE
        SceneManager.LoadScene("Scene13");
    }
}
